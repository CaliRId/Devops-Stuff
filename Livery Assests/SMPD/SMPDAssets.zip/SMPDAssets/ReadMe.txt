Santa Monica Police Department Asset Pack
 Created for California RP, FiveM
 By: bright#3621, any issues DM @bright#3621 or email bright.ktsh@gmail.com.

Humanist 777 - "POLICE" text
Bodoni MT Black - "Santa Monica" text
Harmonia Sans - Numbers
Rolphie 10 Black - "Harbor/Supervisor" text
(Not available for free, use https://en.likefont.com/font/11991074/#download and copy the result)

PXZ is usable as a C + P using pixlr.net (use pixlr e)
PNG is usable as a cut out using any editor.

Any issues DM @bright#3621 or email bright.ktsh@gmail.com, if you need help with designing I can do it or can give advice.